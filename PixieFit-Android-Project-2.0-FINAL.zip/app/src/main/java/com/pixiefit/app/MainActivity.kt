package com.pixiefit.app

import android.app.*
import android.os.Bundle
import android.content.Context
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.view.*
import android.view.inputmethod.InputMethodManager
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.max
import kotlin.math.min

class MainActivity : Activity() {
    private lateinit var ui: PixieView
    private val prefs by lazy { getSharedPreferences("pixiefit", Context.MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ui = PixieView(this, prefs)
        setContentView(ui)
    }

    fun inputDialog(title: String, hint: String, initial: String = "", onSave: (String) -> Unit) {
        val box = EditText(this).apply {
            this.hint = hint
            setText(initial)
            setSelectAllOnFocus(true)
            inputType = android.text.InputType.TYPE_CLASS_TEXT or
                    android.text.InputType.TYPE_CLASS_NUMBER or
                    android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
            setPadding(28, 18, 28, 18)
        }
        AlertDialog.Builder(this)
            .setTitle(title)
            .setView(box)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Save") { _, _ ->
                onSave(box.text.toString().trim())
                ui.invalidate()
            }
            .create().also {
                it.setOnShowListener { dialog ->
                    box.requestFocus()
                    (dialog as? Dialog)?.window?.setSoftInputMode(
                        WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE
                    )
                }
                it.show()
            }
    }

    fun chooseDialog(title: String, options: List<String>, onChoose: (String) -> Unit) {
        AlertDialog.Builder(this)
            .setTitle(title)
            .setItems(options.toTypedArray()) { _, which -> onChoose(options[which]) }
            .show()
    }

    fun drinkDialog() {
        val drinkTypes = arrayOf("Coffee", "Tea", "Rooibos tea", "Hot chocolate", "Smoothie", "Juice", "Soft drink", "Custom drink")
        chooseDialog("Add Drink", drinkTypes.toList()) { type ->
            val layout = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(32, 8, 32, 0)
            }

            fun field(label: String, hint: String, inputType: Int): EditText {
                val l = TextView(this).apply { text = label; textSize = 13f; setPadding(0, 10, 0, 4) }
                layout.addView(l)
                return EditText(this).apply {
                    this.hint = hint
                    this.inputType = inputType
                    setPadding(18, 14, 18, 14)
                    layout.addView(this)
                }
            }

            val cups = field("SERVINGS / CUPS", "1", android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL)
            val sugar = if (type == "Coffee" || type == "Tea" || type == "Rooibos tea") {
                field("SUGAR (teaspoons)", "0", android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL)
            } else null
            val milk = if (type == "Coffee" || type == "Tea" || type == "Rooibos tea" || type == "Hot chocolate") {
                field("MILK (ml)", "0", android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL)
            } else null

            val customCalories = if (type == "Custom drink") {
                field("CALORIES PER SERVING", "0", android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL)
            } else null

            val milkType = if (milk != null) {
                val spinner = Spinner(this)
                val types = arrayOf("Full-cream milk", "Low-fat milk")
                spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, types)
                layout.addView(TextView(this).apply { text = "MILK TYPE"; textSize = 13f; setPadding(0,10,0,4) })
                layout.addView(spinner)
                spinner
            } else null

            val note = TextView(this).apply {
                text = "Calories are estimates. You can adjust values later in Settings."
                textSize = 12f
                setPadding(0, 14, 0, 4)
            }
            layout.addView(note)

            AlertDialog.Builder(this)
                .setTitle(type)
                .setView(layout)
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Add Drink") { _, _ ->
                    val servings = cups.text.toString().toDoubleOrNull() ?: 1.0
                    val sugarTsp = sugar?.text.toString().toDoubleOrNull() ?: 0.0
                    val milkMl = milk?.text.toString().toDoubleOrNull() ?: 0.0

                    val base = when (type) {
                        "Coffee" -> 2.0
                        "Tea", "Rooibos tea" -> 1.0
                        "Hot chocolate" -> 75.0
                        "Smoothie" -> 150.0
                        "Juice" -> 110.0
                        "Soft drink" -> 140.0
                        else -> 0.0
                    }
                    val sugarCal = sugarTsp * 16.0
                    val milkCalPer100 = if (milkType?.selectedItemPosition == 1) 45.0 else 61.0
                    val milkCal = milkMl * milkCalPer100 / 100.0
                    val perServing = if (type == "Custom drink") {
                        customCalories?.text.toString().toDoubleOrNull() ?: 0.0
                    } else base + sugarCal + milkCal
                    val total = max(0.0, perServing * servings)

                    addCalories(total, "$type (${format(servings)} serving${if (servings == 1.0) "" else "s"})")
                    Toast.makeText(this, "Added ${format(total)} kcal", Toast.LENGTH_SHORT).show()
                    ui.invalidate()
                }
                .show()
        }
    }

    fun addCalories(cal: Double, name: String) {
        val day = dayKey()
        val total = prefs.getFloat("cal_$day", 0f) + cal.toFloat()
        prefs.edit()
            .putFloat("cal_$day", total)
            .putString("last_food_$day", name)
            .apply()
    }

    fun addWater(amount: Int) {
        val day = dayKey()
        val total = prefs.getInt("water_$day", 0) + amount
        prefs.edit().putInt("water_$day", total).apply()
        ui.invalidate()
    }

    fun foodDialog() {
        val foods = listOf(
            "Egg — 78 kcal each",
            "Chicken breast — 165 kcal / 100g",
            "Steak — 250 kcal / 100g",
            "Fish — 120 kcal / 100g",
            "Rice — 130 kcal / 100g",
            "Pasta — 157 kcal / 100g",
            "Potato — 77 kcal / 100g",
            "Mixed vegetables — 80 kcal / serving",
            "Salad — 50 kcal / serving",
            "Lasagna — 350 kcal / serving",
            "Coco Pops — 115 kcal / 30g",
            "Yoghurt — 100 kcal / serving",
            "Banana — 105 kcal each",
            "Apple — 95 kcal each",
            "Bread — 80 kcal / slice",
            "Custom food"
        )
        chooseDialog("Quick Food", foods) { selected ->
            if (selected == "Custom food") {
                logFood()
            } else {
                val parts = selected.split(" — ")
                val name = parts[0]
                val calories = Regex("""[0-9]+(?:\\.[0-9]+)?""").find(parts.getOrElse(1) { "0" })?.value?.toDoubleOrNull() ?: 0.0
                inputDialog("Add $name", "Calories", calories.toString()) { value ->
                    val adjusted = value.toDoubleOrNull() ?: calories
                    addCalories(adjusted, name)
                    Toast.makeText(this, "Added ${format(adjusted)} kcal", Toast.LENGTH_SHORT).show()
                    ui.invalidate()
                }
            }
        }
    }

    fun logFood() {
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 8, 32, 0)
        }
        val name = EditText(this).apply { hint = "Food name"; setPadding(18,14,18,14) }
        val calories = EditText(this).apply {
            hint = "Calories"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
            setPadding(18,14,18,14)
        }
        val serving = EditText(this).apply { hint = "Serving / portion"; setPadding(18,14,18,14) }
        layout.addView(name); layout.addView(calories); layout.addView(serving)
        AlertDialog.Builder(this).setTitle("Add Food").setView(layout)
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Add Food") { _, _ ->
                val cal = calories.text.toString().toDoubleOrNull() ?: 0.0
                if (name.text.isNotBlank()) addCalories(cal, name.text.toString())
                Toast.makeText(this, "Food added", Toast.LENGTH_SHORT).show()
                ui.invalidate()
            }.show()
    }

    private fun format(n: Double): String = if (n % 1.0 == 0.0) n.toInt().toString() else "%.1f".format(Locale.US, n)
    private fun dayKey() = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
}

class PixieView(private val activity: MainActivity, private val prefs: android.content.SharedPreferences) : View(activity) {
    private val burgundy = Color.rgb(165, 72, 112)
    private val bg = Color.rgb(252, 248, 250)
    private val card = Color.WHITE
    private val text = Color.rgb(58, 37, 43)
    private val muted = Color.rgb(128, 107, 114)
    private val pink = Color.rgb(247, 233, 238)
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val dateFmt = SimpleDateFormat("yyyy-MM-dd", Locale.US)
    private var tab = 0

    private fun dayKey() = dateFmt.format(Date())
    private fun calories() = prefs.getFloat("cal_${dayKey()}", 0f).toDouble()
    private fun water() = prefs.getInt("water_${dayKey()}", 0)
    private fun weight() = prefs.getFloat("weight", 83f).toDouble()
    private fun goalWeight() = prefs.getFloat("goal_weight", 70f).toDouble()
    private fun calGoal() = prefs.getFloat("cal_goal", 1700f).toDouble()
    private fun waterGoal() = prefs.getInt("water_goal", 2000)

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        c.drawColor(bg)
        header(c)
        when (tab) {
            0 -> home(c)
            1 -> food(c)
            2 -> add(c)
            3 -> progress(c)
            else -> settings(c)
        }
        nav(c)
    }

    private fun header(c: Canvas) {
        paint.color = Color.WHITE
        c.drawRect(0f, 0f, width.toFloat(), 86f, paint)
        paint.color = burgundy
        c.drawCircle(54f, 43f, 26f, paint)
        txt(c, "P", 54f, 52f, 24f, Color.WHITE, true, true)
        txt(c, "PixieFit", 100f, 51f, 24f, text, true)
        paint.color = pink
        c.drawCircle(width - 54f, 43f, 25f, paint)
        txt(c, "T", width - 54f, 51f, 18f, burgundy, true, true)
    }

    private fun home(c: Canvas) {
        txt(c, "Good morning,", 38f, 150f, 38f, text, true)
        txt(c, "Tanja ❤️", 38f, 194f, 38f, text, true)
        txt(c, "A gentle check-in with yourself.", 38f, 226f, 15f, muted)
        button(c, 38f, 250f, width-38f, 312f, "＋  Add to today", true)

        card(c, 38f, 340f, width-38f, 520f)
        txt(c, "TODAY'S RHYTHM", 62f, 382f, 15f, burgundy, true)
        txt(c, "Nourish yourself,", 62f, 430f, 31f, text, true)
        txt(c, "one choice at a time.", 62f, 468f, 31f, text, true)

        val remaining = max(0.0, calGoal() - calories())
        txt(c, "✓   ${format(calories())} kcal consumed", 70f, 520f, 17f, text, true)
        txt(c, "${format(remaining)} kcal left for today", 92f, 548f, 15f, muted)

        card(c, 38f, 540f, width-38f, 700f)
        txt(c, "HYDRATION", 62f, 580f, 15f, burgundy, true)
        txt(c, "${water()} / ${waterGoal()} ml", 62f, 628f, 28f, text, true)
        txt(c, "${formatPercent(water().toDouble(), waterGoal().toDouble())} hydrated", 62f, 658f, 14f, muted)
        progressBar(c, 62f, 680f, width-62f, 696f, min(1f, water().toFloat()/waterGoal()))
        txt(c, "CURRENT WEIGHT", 62f, 750f, 15f, burgundy, true)
        txt(c, "${format(weight())} kg", 62f, 792f, 28f, text, true)
        txt(c, "Goal ${format(goalWeight())} kg", 62f, 820f, 14f, muted)
    }

    private fun food(c: Canvas) {
        txt(c, "Food", 38f, 145f, 38f, text, true)
        txt(c, "Everything you eat and drink today.", 38f, 177f, 15f, muted)
        card(c, 38f, 205f, width-38f, 360f)
        txt(c, "TODAY'S CALORIES", 62f, 248f, 15f, burgundy, true)
        txt(c, "${format(calories())} kcal", 62f, 298f, 34f, text, true)
        txt(c, "${format(max(0.0, calGoal()-calories()))} kcal remaining", 62f, 327f, 15f, muted)
        progressBar(c, 62f, 350f, width-62f, 366f, min(1f, (calories()/calGoal()).toFloat()))
        txt(c, "Last entry", 62f, 420f, 13f, burgundy, true)
        txt(c, prefs.getString("last_food_${dayKey()}", "Nothing logged yet") ?: "Nothing logged yet", 62f, 448f, 17f, text)
        button(c, 62f, 475f, width-62f, 530f, "＋ Add food", true)
        txt(c, "Quick Food gives you calorie estimates; choose Custom food when needed.", 62f, 595f, 13f, muted)
    }

    private fun add(c: Canvas) {
        txt(c, "Add to today", 38f, 145f, 38f, text, true)
        txt(c, "Choose what you'd like to log.", 38f, 177f, 15f, muted)
        button(c, 38f, 215f, width-38f, 285f, "🍽  Add Food", true)
        button(c, 38f, 305f, width-38f, 375f, "☕  Add Drink", true)
        button(c, 38f, 395f, width-38f, 465f, "💧  Add Water", false)
        button(c, 38f, 485f, width-38f, 555f, "⚖  Log Weight", false)
        button(c, 38f, 575f, width-38f, 645f, "📝  Add Note", false)
    }

    private fun progress(c: Canvas) {
        txt(c, "Your Progress", 38f, 145f, 38f, text, true)
        txt(c, "Small choices add up.", 38f, 177f, 15f, muted)
        card(c, 38f, 205f, width-38f, 450f)
        txt(c, "CURRENT WEIGHT", 62f, 248f, 14f, burgundy, true)
        txt(c, "${format(weight())} kg", 62f, 296f, 34f, text, true)
        txt(c, "GOAL WEIGHT", 62f, 350f, 14f, burgundy, true)
        txt(c, "${format(goalWeight())} kg", 62f, 398f, 34f, text, true)
        val lost = max(0.0, 83.0 - weight())
        txt(c, "Weight lost", 62f, 445f, 14f, muted)
        txt(c, "${format(lost)} kg", 62f, 476f, 22f, text, true)
        txt(c, "Remaining to goal: ${format(max(0.0, weight()-goalWeight()))} kg", 62f, 515f, 15f, muted)
        progressBar(c, 62f, 550f, width-62f, 566f, min(1f, ((83-weight())/(83-goalWeight())).toFloat()))
        txt(c, "Weight history will appear here as you log new weights.", 62f, 615f, 13f, muted)
    }

    private fun settings(c: Canvas) {
        txt(c, "Settings", 38f, 145f, 38f, text, true)
        txt(c, "Make PixieFit yours.", 38f, 177f, 15f, muted)
        card(c, 38f, 205f, width-38f, 660f)
        row(c, "Name", "Tanja", 245f)
        row(c, "Current weight", "${format(weight())} kg", 305f)
        row(c, "Goal weight", "${format(goalWeight())} kg", 365f)
        row(c, "Daily calories", "${format(calGoal())} kcal", 425f)
        row(c, "Daily water", "$waterGoal ml", 485f)
        button(c, 62f, 545f, width-62f, 605f, "Edit goals", false)
        button(c, 62f, 625f, width-62f, 685f, "Reset today's food & water", false)
    }

    private fun nav(c: Canvas) {
        paint.color = Color.WHITE
        c.drawRect(0f, height-88f, width.toFloat(), height.toFloat(), paint)
        val labels = arrayOf("Home","Food","Add","Progress","Settings")
        val xs = floatArrayOf(width*.1f,width*.3f,width*.5f,width*.7f,width*.9f)
        for (i in labels.indices) {
            val selected = tab == i
            if (i == 2) {
                paint.color = burgundy
                c.drawCircle(xs[i], height-55f, 28f, paint)
                txt(c, "+", xs[i], height-47f, 31f, Color.WHITE, false, true)
            } else {
                txt(c, when(i){0->"⌂";1->"♜";3->"⌁";else->"⚙"}, xs[i], height-54f, 27f, if(selected) burgundy else muted, false, true)
            }
            txt(c, labels[i], xs[i], height-18f, 12f, if(selected) burgundy else muted, true, true)
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.action != MotionEvent.ACTION_UP) return true
        val x=e.x; val y=e.y
        if (y > height-100) {
            tab = min(4, max(0, ((x / width)*5).toInt()))
            invalidate()
            return true
        }
        when(tab) {
            0 -> if (y in 245f..320f) { tab=2; invalidate() }
            1 -> if (y in 450f..545f) activity.foodDialog()
            2 -> when {
                y in 205f..295f -> activity.foodDialog()
                y in 295f..390f -> activity.drinkDialog()
                y in 390f..480f -> activity.chooseDialog("Add Water", listOf("250 ml","350 ml","500 ml","750 ml","1,000 ml","Custom amount")) { s ->
                    if (s == "Custom amount") activity.inputDialog("Water amount", "ml") { v -> activity.addWater(v.toIntOrNull() ?: 0) }
                    else activity.addWater(s.replace(",","").substringBefore(" ").toInt())
                }
                y in 480f..570f -> activity.inputDialog("Log Weight", "kg", weight().toString()) { v ->
                    prefs.edit().putFloat("weight", v.toFloatOrNull() ?: weight().toFloat()).apply()
                    invalidate()
                }
                y in 570f..660f -> activity.inputDialog("Daily Note", "How are you feeling?") { v ->
                    prefs.edit().putString("note_${dayKey()}", v).apply()
                }
            }
            4 -> if (y in 540f..620f) {
                activity.inputDialog("Daily goals", "Calories, Water ml", "${calGoal().toInt()}, ${waterGoal()}") { v ->
                    val parts=v.split(",")
                    if(parts.size>=2) prefs.edit().putFloat("cal_goal",parts[0].trim().toFloatOrNull() ?: 1700f).putInt("water_goal",parts[1].trim().toIntOrNull() ?: 2000).apply()
                    invalidate()
                }
            } else if (y in 620f..700f) {
                prefs.edit().remove("cal_${dayKey()}").remove("water_${dayKey()}").apply()
                invalidate()
            }
        }
        return true
    }

    private fun row(c: Canvas, a:String,b:String,y:Float) {
        txt(c,a,62f,y,14f,muted,true); txt(c,b,width-62f,y,16f,text,true,false)
    }
    private fun card(c:Canvas,l:Float,t:Float,r:Float,b:Float) {
        paint.color=card
        c.drawRoundRect(l,t,r,b,28f,28f,paint)
        paint.style=Paint.Style.STROKE; paint.strokeWidth=1f; paint.color=Color.rgb(235,225,229)
        c.drawRoundRect(l,t,r,b,28f,28f,paint); paint.style=Paint.Style.FILL
    }
    private fun button(c:Canvas,l:Float,t:Float,r:Float,b:Float,s:String,filled:Boolean) {
        paint.color=if(filled) burgundy else pink
        c.drawRoundRect(l,t,r,b,28f,28f,paint)
        txt(c,s,(l+r)/2f,(t+b)/2f+7f,16f,if(filled) Color.WHITE else burgundy,true,true)
    }
    private fun progressBar(c:Canvas,l:Float,t:Float,r:Float,b:Float,p:Float) {
        paint.color=pink;c.drawRoundRect(l,t,r,b,8f,8f,paint)
        paint.color=burgundy;c.drawRoundRect(l,t,l+(r-l)*p,b,8f,8f,paint)
    }
    private fun txt(c:Canvas,s:String,x:Float,y:Float,size:Float,col:Int,bold:Boolean=false,center:Boolean=false) {
        paint.color=col;paint.textSize=size;paint.typeface=if(bold) Typeface.create("sans",Typeface.BOLD) else Typeface.create("sans",Typeface.NORMAL)
        paint.textAlign=if(center) Paint.Align.CENTER else Paint.Align.LEFT
        c.drawText(s,x,y,paint)
    }
    private fun format(n:Double)=if(n%1.0==0.0)n.toInt().toString() else "%.1f".format(Locale.US,n)
    private fun formatPercent(v:Double,g:Double)=format(min(100.0,v/g*100.0))+"%"
}